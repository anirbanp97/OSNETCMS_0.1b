﻿/* Params */
function GetParameterByName(name) {
    return GetParameterByNameFromUrl(window.location.search, name);
}
function GetParameterByNameFromUrl(url, name) {
    name = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
    var regexS = "[\\?&]" + name + "=([^&#]*)";
    var regex = new RegExp(regexS);
    var results = regex.exec(url);
    if (results == null)
        return "";
    else
        return decodeURIComponent(results[1].replace(/\+/g, " "));
}
function SetUrlParamValue(curUrl, paramName, paramValue) {
    paramName = paramName + "=";
    var url = curUrl;
    //Если есть параметры, то выставляем '&' в конце
    if (url.indexOf('?') != -1) {
        if (url.charAt(url.length - 1) != '&' && url.charAt(url.length - 1) != '?') {
            url += '&';
        }
    }
    else {
        //Если нет вопроса, то выставляем его
        url += '?';
    }

    //Удаляем старый параметр
    if (url.indexOf(paramName) != -1) {
        url = url.substring(0, url.indexOf(paramName)) + url.substring(GetIndexOf(url, '&', url.indexOf(paramName)) + 1);
    }

    //Выставляем новый параметр
    if (paramValue != '') {
        url += paramName + paramValue + '&';
    }

    if (url.charAt(url.length - 1) == '&') {
        url = url.substring(0, url.length - 1);
    }

    if (url.charAt(url.length - 1) == '?') {
        url = url.substring(0, url.length - 1);
    }

    return url;
}
function GetIndexOf(text, pattern, startWith) {
    text = text.substring(startWith);
    var index = text.indexOf(pattern);
    if (index != -1) {
        index += startWith;
    }
    return index;
}
/* /Params */

/* Resize page */
var IS_DIALOG_PARAM = 'isDialog';
var IS_DIALOG_VALUE = '1';
function IsDialog() {
    var isDialog = GetParameterByName(IS_DIALOG_PARAM);
    return isDialog == IS_DIALOG_VALUE;
}

function ResizePage() {
    return;
    if (!IsDialog()) {
        //Убираем прокрутку
        $('html').css('overflow', 'hidden');
        $('body').css('overflow', 'hidden');

        try
        {
            var topHeight = 91;
            var width = $('body').width();
            var height = $('body').height();

            $("#master-page-top").width(width - 4);
            $("#master-page-left").height(height - topHeight - 2).width(300); /* Левый блок навигации */
            $("#master-page-content-main").height(height - topHeight - 2).width(width - 304 - 2); /* Центральная часть */
            $("#master-page-workarea").height(height - topHeight - 2 - 55 - 39 - 2 - 20); /* Рабочая область */
        }
        finally {
            //Возвращаем прокрутку
            $('html').css('overflow', 'auto');
            $('body').css('overflow', 'auto');
        }
    }
}

$(document).ready(function () {
    ResizePage();
});

$(window).bind('resize', function () {
    ResizePage();
});
/* /Resize page */

/* Ajax */
var isAjax = false;
var elContentDestId = '#master-page-content-main';
var elContentSourceId = '#master-page-content';
var currentUrlElId = '#current-url';
var loaderId = '#loader';
var enctypeParam = 'enctype';

function CheckAndGetElementById(elId) {
    var el = $(elId);
    if (el.length == 0) {
        var newElId = elId.substring(1);
        $('body').prepend('<div id="' + newElId + '"></div>');
        el = $(elId);
    }
    return el;
}
function CheckAndGetElementByIdHidden(elId) {
    var el = $(CheckAndGetElementById(elId));
    el.css('display', 'none');
    return el;
}

function StartLoad() {
    $(loaderId).show();
}
function EndPost() {
    EndLoad();
    CloseDialog();
    RefreshPage();
}
function EndLoad() {
    $(loaderId).hide();
}

function GetCurrentUrlEl() {
    var currentUrlEl = $(CheckAndGetElementByIdHidden(currentUrlElId));
    return currentUrlEl;
}
function SetCurrentUrl(url) {
    var currentUrlEl = $(GetCurrentUrlEl());
    currentUrlEl.text(url);
}
function GetCurrentUrl() {
    var currentUrlEl = $(GetCurrentUrlEl());
    return currentUrlEl.text();
}

function GetContent(url) {
    var loadUrl = url + ' ' + elContentSourceId;

    StartLoad();
    $(elContentDestId).load(loadUrl, EndLoad);

    SetCurrentUrl(url);
}
function PostContentForm(form) {
    var form_data = $(form).serializeArray();

    for (var i = 0; i < form_data.length; i++) {
        alert(form_data[i].name + ': ' + form_data[i].value);
    }

    var url = $(form).attr('action');
    var loadUrl = url + ' ' + elContentSourceId;

    var modal = GetParameterByName(url, dialogParam);

    StartLoad();
    if (modal != '1') {
        $(elContentDestId).load(loadUrl, form_data, EndPost);
    }
    else {
        $.post(loadUrl, form_data, EndPost);
    }
}
function PostContent(el) {
    var form = $(el).parents('form').first();
    PostContentForm(form);
}

function RefreshPage() {
    var url = GetCurrentUrl();
    GetContent(url);
}

function SetGetContentJQuery(el, ev) {
    $(el).live(ev, function () {
        var target = $(this).attr('target');
        if (target == '_blank') {
            return;
        }

        var modal = $(this).attr('modal');
        if (modal == '1') {
            return;
        }

        var url = $(this).attr('href');
        GetContent(url);

        event.preventDefault();
        event.stopPropagation();
    });
}
function SetPostContentJQuery(el, ev) {
    $(el).live(ev, function () {
        PostContentForm(this);
        
        event.preventDefault();
        event.stopPropagation();
    });
}

$(document).ready(function () {
    if (isAjax) {
        SetGetContentJQuery('a', 'click');
        SetPostContentJQuery('form', 'submit');
    }
});
/* /Ajax */

/* Modal */
var dialogId = 'modal-form';
var dialogIdJQ = '#' + dialogId;
var dialogParam = 'dialog';
var dialogParamValue = '1';

function ShowDialog(url) {
    return true;
    url = SetUrlParamValue(url, dialogParam, dialogParamValue); 

    var dialog = $(CheckAndGetElementByIdHidden(dialogIdJQ)); 

    var loadUrl = url + ' ' + elContentSourceId;
    dialog.load(loadUrl, function () {
        $(dialogIdJQ).dialog({
            modal: false,
            width: 800,
            minHeight: 300,
            close: function (event, ui) { $(dialogIdJQ).dialog('destroy'); },
            open: function (event, ui) {
                var windowHeight = $('body').height(); 
                var dialogHeightOuter = $(dialogIdJQ).height();
                
                if (dialogHeightOuter > windowHeight) {
                    $(dialogIdJQ).dialog("option", "height", windowHeight - 5);
                }
            }
        });
    });

    return false;
}
function CloseDialog() {
    var dialog = $(CheckAndGetElementByIdHidden(dialogIdJQ));
    $(dialogIdJQ).dialog('close');
}
/* /Modal */

/* Left menu */
function OpenFolder(el, isLink) {
    var folder = $(el).parent('li');

    if (folder.hasClass('left-menu-item-plusminus')) {
        if (folder.hasClass('left-menu-item-plusminus-open')) {
            if(!isLink) folder.removeClass('left-menu-item-plusminus-open');
        }
        else {
            folder.addClass('left-menu-item-plusminus-open');
        }
    }

    if (folder.hasClass('left-menu-item-folder')) {
        if (folder.hasClass('left-menu-item-folder-open')) {
            if (!isLink) folder.removeClass('left-menu-item-folder-open');
        }
        else {
            folder.addClass('left-menu-item-folder-open');
        }
    }
}
$(document).ready(function () {
    $('.left-menu-item-span').click(function () {
        OpenFolder(this, true);
    });
    $('.left-menu-ico').click(function () {
        var el = $(this).parents('.left-menu-item').first().find('.left-menu-item-span').first();
        OpenFolder(el, false);
    });
    
});
/* /Left menu */

/* Top menu */
$(document).ready(function () {
    SetTopMenu();
});

function SetTopMenu() {
    var currentSectionClass = 'menu-head-item-current';
    var currentItemsClass = 'menu-child-current';
    var currentItemClass = 'menu-child-item-current';

    var menuClass = '.menu-head';
    var sectionClass = '.menu-head-item';
    var itemsClass = '.menu-child';
    var itemClass = '.menu-child-item';

    var currentMenuItem = $('#current-menu-item').text();

    if (currentMenuItem != '') {
        var isFindItem = false;

        $(menuClass).first().find(sectionClass).each(function () {
            $(this).removeClass(currentSectionClass);
            $(this).find(itemsClass).removeClass(currentItemsClass);

            var isCurrentSection = false;
            $(this).find(itemClass).each(function () {
                var itemUrl = $(this).find('a').first().attr('href');

                if (currentMenuItem == itemUrl) {
                    if (!$(this).hasClass(currentItemClass)) {
                        $(this).addClass(currentItemClass);
                    }

                    isFindItem = true;
                    isCurrentSection = true;
                }
            });

            if (isCurrentSection) {
                $(this).addClass(currentSectionClass);
                $(this).find(itemsClass).addClass(currentItemsClass);

                return;
            }
        });

        if (!isFindItem) {
            $(sectionClass).first().addClass(currentSectionClass);
            $(sectionClass).first().find(itemsClass).addClass(currentItemsClass);
        }
    }
}
/* /Top menu */