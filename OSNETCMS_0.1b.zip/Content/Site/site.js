﻿function SetUrlParamValue(curUrl, paramName, paramValue) {
    paramName = paramName + "=";
    var url = curUrl;
    //Если есть параметры, то выставляем '&' в конце
    if (url.indexOf('?') != -1) {
        if (url.charAt(url.length - 1) != '&' && url.charAt(url.length - 1) != '?') {
            url += '&';
        }
    }
    else {
        //Если нет вопроса, то выставляем его
        url += '?';
    }
    
    //Удаляем старый параметр
    if (url.indexOf(paramName) != -1) {
        url = url.substring(0, url.indexOf(paramName)) + url.substring(GetIndexOf(url, '&', url.indexOf(paramName)) + 1);
    }

    //Выставляем новый параметр
    if (paramValue != '') {
        url += paramName + paramValue + '&';
    }

    if (url.charAt(url.length - 1) == '&') {
        url = url.substring(0, url.length - 1);
    }

    if (url.charAt(url.length - 1) == '?') {
        url = url.substring(0, url.length - 1);
    }

    return url;
}
function GetIndexOf(text, pattern, startWith) {
    text = text.substring(startWith);
    var index = text.indexOf(pattern);
    if (index != -1) {
        index += startWith;
    }
    return index;
}

function GoToPage(page, el) {
    var webPartId = $(el).parents('div[cmswebpart=list]').first().attr('cmswebpartid');
    var pageParam = 'pagefor_' + webPartId;
    var redirectUrl = SetUrlParamValue(location.href, pageParam, page);
    location.href = redirectUrl;
}

